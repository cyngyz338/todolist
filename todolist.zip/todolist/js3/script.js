const todoinput = document.getElementById('todoinput');
const addtodobtn = document.getElementById('addtodobtn');
const todolist = document.getElementById('todolist');


function addTodo(){
    let todoinputitem = todoinput.value;
    let todoitem = document.createElement('li');
    if(todoinput.value !== ''){
        todoitem.innerText = todoinputitem;

        const deleteBtn = document.createElement('button');
        deleteBtn.innerText = 'удалить';
        deleteBtn.classList.add('deleteBtn');
        

        deleteBtn.addEventListener('click', () =>{
        todolist.removeChild(todoitem);
 })

        todoitem.appendChild(deleteBtn);
        todolist.appendChild(todoitem);
        todoinput.value = '';
        

        }else{
            alert('тапшырма жазыныз')
    }
}